// Battle logic goes here
