// Main bot entry point
